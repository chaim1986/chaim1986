import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserComponent } from './user.component';
import { Routes, RouterModule } from '@angular/router';
import { UserAreaComponent } from './user-area/user-area.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { UserDetailsComponent } from './user-details/user-details.component';
import { FaultReportComponent } from './fault-report/fault-report.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { VoteScreenComponent } from './vote-screen/vote-screen.component';



const routes: Routes = [

  { path: 'userarea/:id', component: UserAreaComponent },
  { path: '', component: UserComponent },
  { path: 'userdetails/:id', component: UserDetailsComponent },
  { path: 'userreport/:id', component: FaultReportComponent },
  { path: 'uservoterscreen/:id', component: VoteScreenComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class userRoutingModule{ }


@NgModule({
  declarations: [UserComponent, UserAreaComponent, UserDetailsComponent, FaultReportComponent, VoteScreenComponent],
  imports: [
    CKEditorModule,
    CommonModule,
    HttpClientModule,
    FormsModule, userRoutingModule
  ],
  bootstrap: [UserComponent]

})
export class UserModule { }
