import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ElectionService } from '../../../../Services/election.service';

@Component({
  selector: 'app-user-area',
  templateUrl: './user-area.component.html',
  styleUrls: ['./user-area.component.css']
})
export class UserAreaComponent implements OnInit {

  constructor(private service: ElectionService, private route: ActivatedRoute) {
    route.params.subscribe(u => { this.userid = +u['id']; });
  }

  elections: any = [];
  userid: any
  user: any

  ngOnInit() {

    this.service.getElections(this.userid).subscribe(e => { this.elections = e; });
    this.service.getUserDetails(this.userid).subscribe(u => { this.user = u; })

  }

}
