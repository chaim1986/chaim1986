import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { InspectorComponent } from './inspector.component';
import { InpectorScreenComponent } from './inpector-screen/inpector-screen.component';


const routes: Routes = [
  { path: '', component: InspectorComponent },
  { path: 'inspectorscreenarea/:id', component: InpectorScreenComponent }
];

@NgModule({
  declarations: [InspectorComponent, InpectorScreenComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class InspectorModule { }
