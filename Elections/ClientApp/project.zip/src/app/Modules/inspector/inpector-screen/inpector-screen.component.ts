import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ElectionService } from '../../../../Services/election.service';

@Component({
  selector: 'app-inpector-screen',
  templateUrl: './inpector-screen.component.html',
  styleUrls: ['./inpector-screen.component.css']
})
export class InpectorScreenComponent implements OnInit {

  userId: number

  constructor(private service: ElectionService, private route: ActivatedRoute, private router: Router) {
    route.params.subscribe(u => { this.userId = +u['id']; })

  }

  ngOnInit() {
  }

}
