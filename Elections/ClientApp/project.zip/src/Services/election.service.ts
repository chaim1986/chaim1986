import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ElectionService {

  constructor(private http: HttpClient) { }

  baseurl = environment.baseurl;

  getElections(userid: number) {
    return this.http.get(this.baseurl+ '/api/elections/GetElectionsOfUser/' + userid);
  }

  getUserDetails(userid: number) {
    return this.http.get(this.baseurl + '/api/users/' + userid);
  }

  updateUser(userId: number, userdetails) {
    return this.http.put('/api/users/' + userId, userdetails);
  }

  deleteUser(userid: number) {
    return this.http.delete('/api/users/' + userid);
  }

  faulteReport(faulte) {
    return this.http.post('/api/faults', faulte);
  }

  getAreaOfUser(userId: number, electionId: number) {
    return this.http.get('/api/area?electionId=' + electionId + '&userId=' + userId)
  }

  getOptionsToVote(electionId: number) {
    return this.http.get('/api/option/GetOptionsOfElection/' + electionId)
  }

  updateVote(id: number, vote: any) {
    return this.http.put('/api/voters/SetVote/' + id, vote)
  }


}
