
export const environment = {
  production: false, baseurl: "https://localhost:44316"
};
